#!/bin/bash
#
# Install the ECG demo system. This script MUST be run in the script's
# directory (e.g. ./instsall.sh).
# 
# Once the install is finished, you can delete everything under the
# "build" directory.
#
# To run tools that depend on those installed by this script,
# you must manually include INSTALLDIR in your path, libraries,
# etc.

#
# User configurable variables
#

# Change INSTALLDIR to e.g. /usr/local if you want to install globally
# rather than just within this directory. Change with caution!
INSTALLDIR=$PWD

# No user configuration below this point.

# Prepend or set PKG_CONFIG_PATH
export PKG_CONFIG_PATH=$INSTALLDIR/lib/pkgconfig${PKG_CONFIG_PATH:+:$PKG_CONFIG_PATH}

# Prepend or set LD_LIBRARY_PATH
export LD_LIBRARY_PATH=$INSTALLDIR/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}

# Prepend or set PYTHONPATH
export PYTHONPATH=$INSTALLDIR/lib/python${PYTHONPATH:+:$PYTHONPATH}

mkdir -p build
cd build

# ZeroMQ 4.1.0-rc1
# http://download.zeromq.org/zeromq-4.1.0-rc1.tar.gz
#
# Standard open source pacakge C/C++ install method.

if ! test -e $INSTALLDIR/include/zmq.h -a -e $INSTALLDIR/lib/libzmq.a; then
  echo Installing ZeroMQ
  cd $INSTALLDIR/build
  tar xzf ../tars/zeromq-4.1.0-rc1.tar.gz
  cd zeromq-4.1.0
  ./configure --prefix=$INSTALLDIR
  make
  make install
fi

# Python bindings to ZeroMQ
# pyzmq 14.6.0
# https://pypi.python.org/packages/source/p/pyzmq/pyzmq-14.6.0.tar.gz#md5=395b5de95a931afa5b14c9349a5b8024
#
# Python install where you need more control than pip gives you.

if ! test -e $INSTALLDIR/lib/python/zmq/__init__.py; then
  echo Installing pyzmq
  cd $INSTALLDIR/build
  tar xzf ../tars/pyzmq-14.6.0.tar.gz
  cd pyzmq-14.6.0
  python setup.py configure --zmq=$INSTALLDIR
  python setup.py install --home=$INSTALLDIR
fi

# Python port of Lyre
# pyre, version as of May 5 2015
# https://github.com/zeromq/pyre/archive/master.zip

if ! test -e $INSTALLDIR/lib/python/pyre-0.2-py2.7.egg; then
  echo Installing pyre
  cd $INSTALLDIR/build
  tar xzf ../tars/pyre-master-20150529.tar.gz
  cd pyre-master
  python setup.py install --home=$INSTALLDIR
fi
